package com.ssafy.crafts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CraftsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CraftsApplication.class, args);
	}

}
