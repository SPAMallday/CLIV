package com.ssafy.crafts.api.service;

import com.ssafy.crafts.config.SecurityConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class KakaoAuthServiceTest {

    KakaoAuthService kakaoAuthService;

    @BeforeEach
    public void beforeEach() {
        SecurityConfig securityConfig = new SecurityConfig();

    }

    @Test
    void login()

}